package com.hackhub.hackhub.dto;

public class AggiungiMembroDTO {
    private Long teamId;
    private Long utenteId;

    // Getter e Setter
    public Long getTeamId() { return teamId; }
    public void setTeamId(Long teamId) { this.teamId = teamId; }
    public Long getUtenteId() { return utenteId; }
    public void setUtenteId(Long utenteId) { this.utenteId = utenteId; }
}