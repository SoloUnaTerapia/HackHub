package com.hackhub.hackhub.state;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;
import com.hackhub.hackhub.model.Utente;

public class StatoInIscrizione implements HackathonState {
    @Override
    public void iscriviTeam(Hackathon h, Team t) {
        h.getTeamsIscritti().add(t);
        t.setHackathon(h);
    }

    @Override
    public void avanzaStato(Hackathon h) {
        h.setTipoStato(TipoStato.IN_CORSO);
    }
    @Override
    public void uploadSottomissione(Hackathon h) {
        throw new RuntimeException("Errore: Non puoi inviare lavori adesso. L'Hackathon non è In Corso!");
    }

    @Override
    public void valutaSottomissione(Hackathon h) {
        throw new RuntimeException("Errore: non è possibile valutare; L'evento è in iscrizione.");

    }

    @Override
    public void proclamaVincitore(Hackathon h) {
        throw new RuntimeException("Errore: non è possibile proclamare il vincitore; L'evento è in iscrizione.");

    }

    @Override
    public void assegnaGiudice(Hackathon h, Utente u) {
        throw new RuntimeException("ERRORE: Il Giudice può essere assegnato solo nella fase iniziale di Creazione!");
    }
}