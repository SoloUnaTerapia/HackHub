package com.hackhub.hackhub.state;

import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;

public class StatoConcluso implements HackathonState {
    @Override
    public void iscriviTeam(Hackathon h, Team t) {
        throw new RuntimeException("Evento Concluso!");
    }

    @Override
    public void avanzaStato(Hackathon h) {
        throw new RuntimeException("L'evento è già terminato!");
    }

    @Override
    public void uploadSottomissione(Hackathon h) {
        throw new RuntimeException("Evento Concluso!");
    }

    @Override
    public void valutaSottomissione(Hackathon h) {
        throw new RuntimeException("Evento Concluso!");
    }

    @Override
    public void proclamaVincitore(Hackathon h) {
        throw new RuntimeException("Vincitore già proclamato!");
    }
}
