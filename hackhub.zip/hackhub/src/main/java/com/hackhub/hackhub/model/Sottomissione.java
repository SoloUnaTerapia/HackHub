package com.hackhub.hackhub.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
/**
 * Rappresenta il progettoconsegnato da un Team per una Traccia
 * Gestisce un proprio mini-ciclo di vita interno (Bozza -> Completata) per
 * impedire modifiche accidentali dopo la consegna definitiva
 */
@Entity
public class Sottomissione {

    public enum StatoSottomissione { BOZZA, COMPLETATA }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String testoSoluzione;
    private String urlProgetto;
    private LocalDateTime dataUltimaModifica;

    @Enumerated(EnumType.STRING)
    private StatoSottomissione stato;

    @ManyToOne
    @JoinColumn(name = "team_id")
    private Team team;

    @ManyToOne
    @JoinColumn(name = "autore_id")
    private Utente autore;

    @ManyToOne
    @JoinColumn(name = "traccia_id")
    private Traccia traccia;

    public Sottomissione() {}

    public Sottomissione(Team team, Traccia traccia, Utente autore) {
        this.team = team;
        this.traccia = traccia;
        this.autore = autore;
        this.stato = StatoSottomissione.BOZZA;
        this.dataUltimaModifica = LocalDateTime.now();
    }

    public void lavora(String testo, String url, Utente autore) {
        this.testoSoluzione = testo;
        this.urlProgetto = url;
        this.autore = autore;
        this.dataUltimaModifica = LocalDateTime.now();
    }

    public void completa() {
        this.stato = StatoSottomissione.COMPLETATA;
        this.dataUltimaModifica = LocalDateTime.now();
    }


    public Long getId() { return id; }
    public String getTestoSoluzione() { return testoSoluzione; }
    public String getUrlProgetto() { return urlProgetto; }
    public StatoSottomissione getStato() { return stato; }
    public Team getTeam() { return team; }
    public Traccia getTraccia() { return traccia; }
    public Utente getAutore() { return autore; }
}