package com.hackhub.hackhub.adapter;
import java.time.LocalDateTime;
/**
 * [PATTERN ADAPTER] - Ruolo: TARGET
 *
 * Questa interfaccia definisce il contratto standard che il nostro dominio (HackHub)
 * si aspetta per interagire con i sistemi di calendario.
 * In questo modo, i nostri Service non dipendono mai direttamente da servizi terzi(es google),
 * garantendo un basso accoppiamento (Low Coupling)
 */
public interface CalendarService {

    /**
     * Prenota uno slot temporale per una videochiamata
     *
     * @param emailMentore L'email del mentore che organizza la call
     * @param emailTeam L'email del referente del team
     * @param orario L'orario in cui è programmata la call
     * @return Il link generato per la riunione (es. Google Meet)
     */

    String prenotaSlot(String emailMentore, String emailTeam, LocalDateTime orario);
}