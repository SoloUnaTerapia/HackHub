package com.hackhub.hackhub.controller;



import com.hackhub.hackhub.model.*;
import com.hackhub.hackhub.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/segnalazioni")
public class SegnalazioneController {

    @Autowired private SegnalazioneRepository segnRepo;
    @Autowired private UtenteRepository uRepo;
    @Autowired private TeamRepository tRepo;
    @Autowired private HackathonRepository hRepo;

    @PostMapping("/crea")
    public ResponseEntity<?> segnala(@RequestParam Long mentoreId, @RequestParam Long teamId, @RequestParam Long hackId, @RequestParam String msg) {
        Utente m = uRepo.findById(mentoreId).orElseThrow();
        Team t = tRepo.findById(teamId).orElseThrow();
        Hackathon h = hRepo.findById(hackId).orElseThrow();

        if (!h.getMentori().contains(m)) return ResponseEntity.badRequest().body("Non sei un mentore di questo evento!");

        Segnalazione s = new Segnalazione(msg, m, t, h);
        segnRepo.save(s);
        return ResponseEntity.ok("Segnalazione inviata all'organizzatore! ID: " + s.getId());
    }
}
