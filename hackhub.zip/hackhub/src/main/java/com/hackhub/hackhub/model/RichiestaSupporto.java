package com.hackhub.hackhub.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
/**
 * Entità che abilita la comunicazione asincrona tra Team e Mentore.
 * Memorizza lo stato dell'integrazione con l'Adapter Calendar salvando
 * il link del meeting generato dinamicamente.
 */
@Entity
public class RichiestaSupporto {

    public enum StatoRichiesta { IN_ATTESA, CALL_PROGRAMMATA, RISOLTA }

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String messaggioProblema;
    private LocalDateTime orarioCall;
    private String linkMeet;

    @Enumerated(EnumType.STRING)
    private StatoRichiesta stato = StatoRichiesta.IN_ATTESA;

    @ManyToOne @JoinColumn(name = "team_id")
    private Team team;

    @ManyToOne @JoinColumn(name = "mentore_id")
    private Utente mentore;

    @ManyToOne @JoinColumn(name = "hackathon_id")
    private Hackathon hackathon;

    public RichiestaSupporto() {}

    public RichiestaSupporto(String messaggio, Team team, Utente mentore, Hackathon h) {
        this.messaggioProblema = messaggio;
        this.team = team;
        this.mentore = mentore;
        this.hackathon = h;
    }


    public Long getId() { return id; }
    public Team getTeam() { return team; }
    public Utente getMentore() { return mentore; }
    public String getMessaggioProblema() { return messaggioProblema; }
    public StatoRichiesta getStato() { return stato; }
    public LocalDateTime getOrarioCall() { return orarioCall; }
    public String getLinkMeet() { return linkMeet; }
    public void impostaCall(LocalDateTime orario, String link) {
        this.orarioCall = orario;
        this.linkMeet = link;
        this.stato = StatoRichiesta.CALL_PROGRAMMATA;

    }

}