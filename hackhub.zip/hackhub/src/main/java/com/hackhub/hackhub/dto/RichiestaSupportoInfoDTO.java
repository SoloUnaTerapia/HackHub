package com.hackhub.hackhub.dto;

public class RichiestaSupportoInfoDTO {
    private Long id;
    private String nomeTeam;
    private String messaggio;
    private String stato;
    private String orarioCall;
    private String linkMeet;

    public RichiestaSupportoInfoDTO(Long id, String nomeTeam, String messaggio, String stato, String orarioCall, String linkMeet) {
        this.id = id;
        this.nomeTeam = nomeTeam;
        this.messaggio = messaggio;
        this.stato = stato;
        this.orarioCall = orarioCall;
        this.linkMeet = linkMeet;
    }

    // Getter
    public Long getId() { return id; }
    public String getNomeTeam() { return nomeTeam; }
    public String getMessaggio() { return messaggio; }
    public String getStato() { return stato; }
    public String getOrarioCall() { return orarioCall; }
    public String getLinkMeet() { return linkMeet; }
}