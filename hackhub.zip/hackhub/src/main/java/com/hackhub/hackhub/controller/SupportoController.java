package com.hackhub.hackhub.controller;

import com.hackhub.hackhub.dto.GestioneCallDTO;
import com.hackhub.hackhub.service.SupportoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/supporto")
public class SupportoController {

    @Autowired private SupportoService supportoService;


    @PostMapping("/chiedi")
    public ResponseEntity<?> chiedi(
            @RequestParam Long teamId,
            @RequestParam Long mentoreId,
            @RequestParam Long hackathonId,
            @RequestParam String msg) {
        try {

            var r = supportoService.chiediAiuto(teamId, mentoreId, hackathonId, msg);
            return ResponseEntity.ok("Richiesta inviata! ID Richiesta: " + r.getId());
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/fissa-call")
    public ResponseEntity<?> fissaCall(@RequestBody GestioneCallDTO dto) {
        try {
            String link = supportoService.programmaCall(dto);
            return ResponseEntity.ok("Call Fissata! link: " + link);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }


    @GetMapping("/bacheca/{mentoreId}")
    public ResponseEntity<?> visualizzaBachecaMentore(@PathVariable Long mentoreId) {
        try {
            return ResponseEntity.ok(supportoService.getRichiesteMentore(mentoreId));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }


}