package com.hackhub.hackhub.service;


import com.hackhub.hackhub.dto.AggiungiMembroDTO;
import com.hackhub.hackhub.dto.CreaTeamDTO;
import com.hackhub.hackhub.dto.IscrizioneTeamDTO;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;
import com.hackhub.hackhub.model.Utente;
import com.hackhub.hackhub.repository.TeamRepository;
import com.hackhub.hackhub.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TeamService {
    @Autowired private com.hackhub.hackhub.repository.HackathonRepository hackathonRepository;
    @Autowired private TeamRepository teamRepository;
    @Autowired private UtenteRepository utenteRepository;

    @Transactional
    public Team creaTeam(CreaTeamDTO dto) {


        Utente leader = utenteRepository.findById(dto.getLeaderId())
                .orElseThrow(() -> new RuntimeException("Errore: Utente non trovato!"));


        if (leader.getTeam() != null) {
            throw new RuntimeException("Errore: L'utente fa già parte di un team!");
        }


        Team nuovoTeam = new Team();
        nuovoTeam.setNome(dto.getNomeTeam());
        nuovoTeam.setLeader(leader);


        nuovoTeam.getMembri().add(leader);


        Team teamSalvato = teamRepository.save(nuovoTeam);


        leader.setTeam(teamSalvato);
        utenteRepository.save(leader);

        return teamSalvato;
    }
    @Transactional
    public void aggiungiMembro(AggiungiMembroDTO dto) {

        Team team = teamRepository.findById(dto.getTeamId())
                .orElseThrow(() -> new RuntimeException("Errore: Team non trovato!"));


        Utente nuovoMembro = utenteRepository.findById(dto.getUtenteId())
                .orElseThrow(() -> new RuntimeException("Errore: Utente non trovato!"));


        if (nuovoMembro.getTeam() != null) {
            throw new RuntimeException("Errore: L'utente " + nuovoMembro.getNome() + " fa già parte di un team!");
        }


        if (team.getHackathon() != null) {
            Hackathon h = team.getHackathon();
            if (h.getOrganizzatore().getId().equals(nuovoMembro.getId()) ||
                    (h.getGiudice() != null && h.getGiudice().getId().equals(nuovoMembro.getId())) ||
                    h.getMentori().contains(nuovoMembro)) {
                throw new RuntimeException("Conflitto: Non puoi aggiungere al team un membro dello Staff dell'Hackathon in corso!");
            }
        }



        nuovoMembro.setTeam(team);
        team.getMembri().add(nuovoMembro);


        utenteRepository.save(nuovoMembro);
    }
    @Transactional
    public void iscriviTeamAdHackathon(IscrizioneTeamDTO dto) {

        Team team = teamRepository.findById(dto.getTeamId())
                .orElseThrow(() -> new RuntimeException("Errore: Team non trovato!"));

        Hackathon hackathon = hackathonRepository.findById(dto.getHackathonId())
                .orElseThrow(() -> new RuntimeException("Errore: Hackathon non trovato!"));

        Utente utente = utenteRepository.findById(dto.getUtenteId())
                .orElseThrow(() -> new RuntimeException("Errore: Utente non trovato!"));


        if (!team.getLeader().getId().equals(utente.getId())) {
            throw new RuntimeException("Errore Sicurezza: Solo il leader del team può effettuare l'iscrizione.");
        }


        hackathon.iscriviTeam(team);


        teamRepository.save(team);
    }


    @Transactional
    public void abbandonaTeam(Long idUtente) {
        Utente utente = utenteRepository.findById(idUtente)
                .orElseThrow(() -> new RuntimeException("Utente non trovato"));

        Team team = utente.getTeam();
        if (team == null) {
            throw new RuntimeException("Non fai parte di nessun team!");
        }


        if (team.getLeader().getId().equals(utente.getId())) {
            throw new RuntimeException("Il Leader non può abbandonare il team. Devi usare 'Sciogli Team'.");
        }


        team.getMembri().remove(utente);
        utente.setTeam(null);


        utenteRepository.save(utente);
    }
}