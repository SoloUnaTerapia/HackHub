package com.hackhub.hackhub.state;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;
import com.hackhub.hackhub.model.Utente;

public class StatoCreazione implements HackathonState {
    @Override
    public void iscriviTeam(Hackathon h, Team t) {
        throw new RuntimeException("Errore: Hackathon non ancora aperto alle iscrizioni!");
    }

    @Override
    public void avanzaStato(Hackathon h) {

        if (h.getGiudice() == null) {
            throw new RuntimeException("Operazione bloccata:assegnare un Giudice prima di aprire le iscrizioni");
        }

        //controllo Mentori (>=1)
        if (h.getMentori() == null || h.getMentori().isEmpty()) {
            throw new RuntimeException("Operazione bloccata:assegnare almeno un Mentore prima di aprire le iscrizioni");
        }

        //se conrolli passano cambio di stato
        h.setTipoStato(TipoStato.IN_ISCRIZIONE);
        h.setStatoComportamento(new StatoInIscrizione());

        System.out.println("requisiti staff verificati. Hackathon in fase di iscrizone");
    }

    @Override
    public void uploadSottomissione(Hackathon h) {
        throw new RuntimeException("Errore: Non puoi inviare lavori adesso; L'Hackathon non è In Corso");
    }

    @Override
    public void valutaSottomissione(Hackathon h) {
        throw new RuntimeException("Errore: non è possibile effettuare una valutazione; L'evento è in Creazione.");

    }

    @Override
    public void proclamaVincitore(Hackathon h) {
        throw new RuntimeException("Errore: non è possibile proclamare il vincitore; L'evento è in creazione.");

    }

    @Override
    public void assegnaGiudice(Hackathon h, Utente u) {
        System.out.println("giudice assegnato");
    }
}