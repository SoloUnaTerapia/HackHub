package com.hackhub.hackhub.adapter;
import org.springframework.stereotype.Component;
/**
 *[PATTERN ADAPTER] - Ruolo: ADAPTEE
 *
 * Questa classe simula una libreria SDK di terze parti (es. fornita da PayPal).
 * Teoricamente questa classe non è modificabile da noi
 */

@Component
public class PayPalExternalApi {


    public boolean sendMoneyTransaction(String accountEmail, String currency, double amount) {
        System.out.println("Connessione al server di PayPal...");
        System.out.println(" Trasferimento di " + amount + " " + currency + " verso l'account: " + accountEmail);
        System.out.println("Esito: SUCCESS ");
        return true;
    }
}
