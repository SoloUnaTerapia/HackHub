package com.hackhub.hackhub.controller;

import com.hackhub.hackhub.dto.AggiungiMembroDTO;
import com.hackhub.hackhub.dto.CreaTeamDTO;
import com.hackhub.hackhub.model.Team;
import com.hackhub.hackhub.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/teams")
public class TeamController {

    @Autowired
    private TeamService teamService;

    @PostMapping("/crea")
    public ResponseEntity<?> creaTeam(@RequestBody CreaTeamDTO dto) {
        try {
            Team teamCreato = teamService.creaTeam(dto);
            return ResponseEntity.ok("Team '" + teamCreato.getNome() + "' creato con successo! ID: " + teamCreato.getId());
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }


    @PostMapping("/aggiungi-membro")
    public ResponseEntity<?> aggiungiMembro(@RequestBody AggiungiMembroDTO dto) {
        try {
            teamService.aggiungiMembro(dto);
            return ResponseEntity.ok("Utente aggiunto al team con successo!");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/iscrivi")
    public ResponseEntity<?> iscriviTeam(@RequestBody com.hackhub.hackhub.dto.IscrizioneTeamDTO dto) {
        try {
            teamService.iscriviTeamAdHackathon(dto);
            return ResponseEntity.ok("SUCCESSO: Il team è stato iscritto all'Hackathon!");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/abbandona/{utenteId}")
    public ResponseEntity<?> abbandonaTeam(@PathVariable("utenteId") Long utenteId) {
        try {
            teamService.abbandonaTeam(utenteId);
            return ResponseEntity.ok("Hai abbandonato il team con successo.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}


