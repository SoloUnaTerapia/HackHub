package com.hackhub.hackhub.model;
import jakarta.persistence.*;

/**
 * Entità di logging e amministrazione.
 * Permette ai Mentori di inviare flag di irregolarità all'Organizzatore
 */
@Entity
public class Segnalazione {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String messaggio;
    @ManyToOne private Utente mentore;
    @ManyToOne private Team teamSospetto;
    @ManyToOne private Hackathon hackathon;

    public Segnalazione() {}
    public Segnalazione(String msg, Utente m, Team t, Hackathon h) {
        this.messaggio = msg; this.mentore = m; this.teamSospetto = t; this.hackathon = h;
    }
    public Long getId() { return id; }
}