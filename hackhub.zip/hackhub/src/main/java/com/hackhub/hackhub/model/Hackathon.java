package com.hackhub.hackhub.model;

import com.hackhub.hackhub.state.*;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Hackathon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titolo;
    private String regolamento;
    private String luogo;
    private double premio;
    private int maxTeamSize;


    // --- LE RELAZIONI ---
    @ManyToOne
    @JoinColumn(name = "organizzatore_id")
    private Utente organizzatore;

    @OneToMany(mappedBy = "hackathon", cascade = CascadeType.ALL)
    private List<Team> teamsIscritti = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "vincitore_id")
    private Team vincitore;



    // ... altre relazioni (organizzatore, teamsIscritti) ...

    // Un hackathon ha UN SOLO giudice.
    // Usiamo ManyToOne perché lo stesso utente potrebbe fare il giudice in più hackathon diversi.
    @ManyToOne
    @JoinColumn(name = "giudice_id")
    private Utente giudice;

    // Un hackathon ha TANTI mentori, e un utente può fare da mentore a TANTI hackathon.
    // Usiamo ManyToMany. Spring creerà in automatico una tabella di mezzo "hackathon_mentori".
    @ManyToMany
    @JoinTable(
            name = "hackathon_mentori",
            joinColumns = @JoinColumn(name = "hackathon_id"),
            inverseJoinColumns = @JoinColumn(name = "utente_id")
    )
    private List<Utente> mentori = new ArrayList<>();

    // --- IL TRUCCO DELLO STATE PATTERN ---

    @Enumerated(EnumType.STRING)
    private TipoStato tipoStato; // QUESTO VIENE SALVATO NEL DATABASE (Es. "CREAZIONE")

    @Transient // QUESTO NON VIENE SALVATO NEL DB, VIVE SOLO IN RAM!
    private HackathonState statoComportamento;

    public Hackathon() {}

    public Hackathon(String titolo, String regolamento, String luogo, double premio, int maxTeamSize, Utente org) {
        this.titolo = titolo;
        this.regolamento = regolamento;
        this.luogo = luogo;
        this.premio = premio;
        this.maxTeamSize = maxTeamSize;
        this.organizzatore = org;
        this.tipoStato = TipoStato.CREAZIONE;
        this.statoComportamento = new StatoCreazione();
    }

    // MAGIA DI SPRING: Appena legge la riga dal Database, esegue questo metodo
    // per "resuscitare" l'oggetto State corretto!
    // MAGIA DI SPRING: Ricarica lo stato corretto dal DB alla RAM
    @PostLoad
    public void initStatoDopoCaricamento() {
        if (this.tipoStato == null) return;

        switch (this.tipoStato) {
            case CREAZIONE:
                this.statoComportamento = new StatoCreazione();
                break;
            case IN_ISCRIZIONE:
                this.statoComportamento = new StatoInIscrizione();
                break;
            case IN_CORSO:
                this.statoComportamento = new StatoInCorso(); // ORA LO TROVA!
                break;
            case IN_VALUTAZIONE:
                // Se non hai ancora creato la classe StatoInValutazione.java, commenta questa riga per ora
                this.statoComportamento = new StatoInValutazione();
                break;
            case CONCLUSO:
                this.statoComportamento = new StatoConcluso();
                break;
        }
    }

    public void setGiudice(Utente giudice) {
        // Controllo: Il giudice non può essere l'organizzatore
        if (this.organizzatore.getId().equals(giudice.getId())) {
            throw new RuntimeException("Errore: L'organizzatore non può essere anche il giudice!");
        }
        // Controllo 2: Il giudice non può essere già un mentore! <--- ECCO IL FIX
        if (this.mentori.contains(giudice)) {
            throw new RuntimeException("Errore: Questo utente è già un mentore per questo Hackathon!");
        }
        for (Team t : this.teamsIscritti) {
            if (t.getMembri().contains(giudice)) {
                throw new RuntimeException("Conflitto di interessi: Il giudice non può far parte di un team partecipante!");
            }
        }

        this.giudice = giudice;
    }

    public void aggiungiMentore(Utente mentore) {
        // Controllo 1: Il mentore non può essere l'organizzatore
        if (this.organizzatore.getId().equals(mentore.getId())) {
            throw new RuntimeException("Errore: L'organizzatore non può fare il mentore!");
        }
        // Controllo 2: Il mentore non può essere il giudice
        if (this.giudice != null && this.giudice.getId().equals(mentore.getId())) {
            throw new RuntimeException("Errore: Il giudice non può fare anche il mentore!");
        }

        for (Team t : this.teamsIscritti) {
            if (t.getMembri().contains(mentore)) {
                throw new RuntimeException("Conflitto di interessi: Il mentore non può far parte di un team partecipante!");
            }
        }
        // Controllo 3: Evitiamo duplicati
        if (!this.mentori.contains(mentore)) {
            this.mentori.add(mentore);
        }

        }

    // --- DELEGAZIONE (Il Pattern in azione) ---
    public void iscriviTeam(Team t) {
        if (t.getMembri().size() > this.maxTeamSize) {
            throw new RuntimeException("Team troppo numeroso per questo Hackathon!");
        }

        // --- NUOVO CONTROLLO DI SICUREZZA: Nessun membro può essere nello Staff ---
        for (Utente membro : t.getMembri()) {
            if (this.organizzatore.getId().equals(membro.getId())) {
                throw new RuntimeException("Conflitto: L'organizzatore (" + membro.getNome() + ") non può partecipare come concorrente!");
            }
            if (this.giudice != null && this.giudice.getId().equals(membro.getId())) {
                throw new RuntimeException("Conflitto: Il giudice (" + membro.getNome() + ") non può partecipare come concorrente!");
            }
            if (this.mentori.contains(membro)) {
                throw new RuntimeException("Conflitto: Un mentore (" + membro.getNome() + ") non può partecipare come concorrente!");
            }
        }

        // Se tutto è pulito, deleghiamo allo Stato (che controlla se le iscrizioni sono aperte)
        this.statoComportamento.iscriviTeam(this, t);
    }

    public void avanzaStato() {
        this.statoComportamento.avanzaStato(this);
    }
// ... altri metodi (iscriviTeam, avanzaStato, ecc) ...

    public void uploadSottomissione() {
        // L'Hackathon delega il controllo al suo stato corrente!
        this.statoComportamento.uploadSottomissione(this);
    }
    public void valutaSottomissione() {
        this.statoComportamento.valutaSottomissione(this);
    }
    public void proclamaVincitore(){
        this.statoComportamento.proclamaVincitore(this);
    }

    // --- GETTER E SETTER (Base) ---
    public Long getId() { return id; }
    public String getTitolo() { return titolo; }
    public Utente getOrganizzatore() { return organizzatore; }
    public List<Team> getTeamsIscritti() { return teamsIscritti; }
    public Utente getGiudice() {return giudice;}
    public List<Utente> getMentori() { return mentori; }
    public void setTipoStato(TipoStato tipoStato) { this.tipoStato = tipoStato; }
    public void setStatoComportamento(HackathonState stato) { this.statoComportamento = stato; }
    public TipoStato getTipoStato() { return tipoStato; }
    public Team getVincitore() { return vincitore; }
    public void setVincitore(Team vincitore) { this.vincitore = vincitore; }

    public double getPremio() {
        return premio;
    }
}
