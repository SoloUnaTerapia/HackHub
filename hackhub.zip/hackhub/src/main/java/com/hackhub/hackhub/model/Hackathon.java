package com.hackhub.hackhub.model;

import com.hackhub.hackhub.state.*;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
/**
 * [PATTERN STATE] - Ruolo: CONTEXT
 *
 * L'Hackathon è l'entità centrale del sistema.
 * applica il principio "Information Expert" di GRASP: protegge i propri dati
 * ed espone metodi che delegano il comportamento allo Stato Corrente
 */
@Entity
public class Hackathon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titolo;
    private String regolamento;
    private String luogo;
    private double premio;
    private int maxTeamSize;

    @Column(nullable = false) private LocalDateTime scadenzaIscrizioni;
    @Column(nullable = false) private LocalDateTime dataInizio;
    @Column(nullable = false) private LocalDateTime dataFine;

    // --- LE RELAZIONI ---
    @ManyToOne @JoinColumn(name = "organizzatore_id") private Utente organizzatore;
    @ManyToOne @JoinColumn(name = "giudice_id") private Utente giudice;
    @ManyToOne @JoinColumn(name = "vincitore_id") private Team vincitore;


    @OneToMany(mappedBy = "hackathon", cascade = CascadeType.ALL)
    private List<Team> teamsIscritti = new ArrayList<>();



    @ManyToMany
    @JoinTable(
            name = "hackathon_mentori",
            joinColumns = @JoinColumn(name = "hackathon_id"),
            inverseJoinColumns = @JoinColumn(name = "utente_id")
    )
    private List<Utente> mentori = new ArrayList<>();


    /**
     * Soluzione architetturale per persistere il Pattern State tramite JPA
     * tipoStato viene salvato sul DB come stringa.
     * statoComportamento (@Transient) vive solo in RAM per applicare il polimorfismo
     */
    @Enumerated(EnumType.STRING)
    private TipoStato tipoStato;

    @Transient
    private HackathonState statoComportamento;

    public Hackathon() {}

    public Hackathon(String titolo, String regolamento, String luogo,
                     double premio, int maxTeamSize,LocalDateTime scadenza,
                     LocalDateTime inizio, LocalDateTime fine, Utente org) {
        this.titolo = titolo;
        this.regolamento = regolamento;
        this.luogo = luogo;
        this.premio = premio;
        this.maxTeamSize = maxTeamSize;
        this.scadenzaIscrizioni = scadenza;
        this.dataInizio = inizio;
        this.dataFine = fine;
        this.organizzatore = org;
        this.tipoStato = TipoStato.CREAZIONE;
        this.statoComportamento = new StatoCreazione();
    }

    /**
     * Callback JPA (@PostLoad):
     * Viene eseguito in automatico da Spring ogni volta che l'oggetto
     * viene letto dal Database. Ricostruisce l'istanza corretta dell'interfaccia State.
     */
    @PostLoad
    public void initStatoDopoCaricamento() {
        if (this.tipoStato == null) return;

        switch (this.tipoStato) {
            case CREAZIONE:
                this.statoComportamento = new StatoCreazione();
                break;
            case IN_ISCRIZIONE:
                this.statoComportamento = new StatoInIscrizione();
                break;
            case IN_CORSO:
                this.statoComportamento = new StatoInCorso();
                break;
            case IN_VALUTAZIONE:
                this.statoComportamento = new StatoInValutazione();
                break;
            case CONCLUSO:
                this.statoComportamento = new StatoConcluso();
                break;
        }
    }



    /**PATTERN STATE*/


    public void setGiudice(Utente giudice) {

        if (this.organizzatore.getId().equals(giudice.getId())) {
            throw new RuntimeException("Errore: l'organizzatore non può essere anche il giudice");
        }
        if (this.mentori.contains(giudice)) {
            throw new RuntimeException("Errore: Questo utente è già un mentore per questo Hackathon");
        }
        for (Team t : this.teamsIscritti) {
            if (t.getMembri().contains(giudice)) {
                throw new RuntimeException("Il giudice non può far parte di un team partecipante");
            }
        }
        this.statoComportamento.assegnaGiudice(this, giudice);


        this.giudice = giudice;
    }


    public void aggiungiMentore(Utente mentore) {


        if (this.organizzatore.getId().equals(mentore.getId())) {
            throw new RuntimeException("Errore: L'organizzatore non può fare il mentore!");
        }

        if (this.giudice != null && this.giudice.getId().equals(mentore.getId())) {
            throw new RuntimeException("Errore: Il giudice non può fare anche il mentore");
        }

        for (Team t : this.teamsIscritti) {
            if (t.getMembri().contains(mentore)) {
                throw new RuntimeException("Il mentore non può far parte di un team partecipante");
            }
        }

        if (!this.mentori.contains(mentore)) {
            this.mentori.add(mentore);
        }

        }


    public void iscriviTeam(Team t) {
        if (t.getMembri().size() > this.maxTeamSize) {
            throw new RuntimeException("Team troppo numeroso per questo Hackathon!");
        }


        for (Utente membro : t.getMembri()) {
            if (this.organizzatore.getId().equals(membro.getId())) {
                throw new RuntimeException("L'organizzatore (" + membro.getNome() + ") non può partecipare come concorrente");
            }
            if (this.giudice != null && this.giudice.getId().equals(membro.getId())) {
                throw new RuntimeException("Il giudice (" + membro.getNome() + ") non può partecipare come concorrente");
            }
            if (this.mentori.contains(membro)) {
                throw new RuntimeException("IL mentore (" + membro.getNome() + ") non può partecipare come concorrente");
            }
        }


        this.statoComportamento.iscriviTeam(this, t);
    }

    public void avanzaStato() {
        this.statoComportamento.avanzaStato(this);
    }


    public void uploadSottomissione() {

        this.statoComportamento.uploadSottomissione(this);
    }
    public void valutaSottomissione() {
        this.statoComportamento.valutaSottomissione(this);
    }
    public void proclamaVincitore(){
        this.statoComportamento.proclamaVincitore(this);
    }


    public Long getId() { return id; }
    public String getTitolo() { return titolo; }
    public Utente getOrganizzatore() { return organizzatore; }
    public List<Team> getTeamsIscritti() { return teamsIscritti; }
    public Utente getGiudice() {return giudice;}
    public List<Utente> getMentori() { return mentori; }
    public void setTipoStato(TipoStato tipoStato) { this.tipoStato = tipoStato; }
    public void setStatoComportamento(HackathonState stato) { this.statoComportamento = stato; }
    public TipoStato getTipoStato() { return tipoStato; }
    public Team getVincitore() { return vincitore; }
    public void setVincitore(Team vincitore) { this.vincitore = vincitore; }
    public LocalDateTime getScadenzaIscrizioni() { return scadenzaIscrizioni; }
    public LocalDateTime getDataInizio() { return dataInizio; }
    public LocalDateTime getDataFine() { return dataFine; }
    public double getPremio() {
        return premio;
    }
}
