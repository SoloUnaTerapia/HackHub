package com.hackhub.hackhub.service;


import com.hackhub.hackhub.dto.RegistrazioneDTO;
import com.hackhub.hackhub.model.Utente;
import com.hackhub.hackhub.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UtenteRepository utenteRepository;

    public Utente registraUtente(RegistrazioneDTO dto) {

        if (utenteRepository.findByEmail(dto.getEmail()).isPresent()) {
            throw new RuntimeException("Errore: Email già registrata!");
        }


        Utente nuovoUtente = new Utente(dto.getNome(), dto.getEmail(), dto.getPassword());


        return utenteRepository.save(nuovoUtente);
    }
}