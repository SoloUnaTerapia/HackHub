package com.hackhub.hackhub.service;

import com.hackhub.hackhub.dto.CreaHackathonDTO;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Utente;
import com.hackhub.hackhub.repository.HackathonRepository;
import com.hackhub.hackhub.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class HackathonService {

    @Autowired private HackathonRepository hackathonRepo;
    @Autowired private UtenteRepository utenteRepo;

    public Hackathon creaHackathon(CreaHackathonDTO dto) {
        Utente org = utenteRepo.findById(dto.getOrganizzatoreId())
                .orElseThrow(() -> new RuntimeException("Organizzatore non trovato"));

        
        LocalDateTime oggi = LocalDateTime.now();

        if (dto.getScadenzaIscrizioni().isBefore(oggi)) {
            throw new RuntimeException("Errore: La scadenza delle iscrizioni deve essere nel futuro!");
        }
        if (dto.getDataInizio().isBefore(dto.getScadenzaIscrizioni())) {
            throw new RuntimeException("Errore: L'evento non può iniziare prima della chiusura delle iscrizioni!");
        }
        if (dto.getDataFine().isBefore(dto.getDataInizio())) {
            throw new RuntimeException("Errore: La data di fine deve essere successiva alla data di inizio!");
        }

        // Creazione con il nuovo costruttore
        Hackathon h = new Hackathon(
                dto.getTitolo(), dto.getRegolamento(), dto.getLuogo(),
                dto.getPremio(), dto.getMaxTeamSize(),
                dto.getScadenzaIscrizioni(), dto.getDataInizio(), dto.getDataFine(),
                org
        );

        return hackathonRepo.save(h);
    }
    @Transactional
    public void assegnaGiudice(Long idHackathon, Long idGiudice, Long orgId) {
        Hackathon h = hackathonRepo.findById(idHackathon)
                .orElseThrow(() -> new RuntimeException("Hackathon non trovato"));
        if (!h.getOrganizzatore().getId().equals(orgId)) {
            throw new RuntimeException("ACCESSO NEGATO: Solo l'organizzatore dell'evento può nominare il giudice!");
        }
        Utente giudice = utenteRepo.findById(idGiudice)
                .orElseThrow(() -> new RuntimeException("utente non trovato"));

        h.setGiudice(giudice);
        hackathonRepo.save(h);
    }

    @Transactional
    public void aggiungiMentore(Long idHackathon, Long idMentore, Long orgId) {
        Hackathon h = hackathonRepo.findById(idHackathon)
                .orElseThrow(() -> new RuntimeException("Hackathon non trovato"));
        if (!h.getOrganizzatore().getId().equals(orgId)) {
            throw new RuntimeException("ACCESSO NEGATO: Solo l'organizzatore dell'evento può nominare il giudice!");
        }
        Utente mentore = utenteRepo.findById(idMentore)
                .orElseThrow(() -> new RuntimeException("utente non trovato"));

        h.aggiungiMentore(mentore);
        hackathonRepo.save(h);
    }
    public void apriIscrizioni(Long hackathonId, Long organizzatoreId) {
        Hackathon h = hackathonRepo.findById(hackathonId)
                .orElseThrow(() -> new RuntimeException("Hackathon non trovato"));

        if (!h.getOrganizzatore().getId().equals(organizzatoreId)) {
            throw new RuntimeException("ACCESSO NEGATO: Solo l'organizzatore dell'evento può aprire le iscrizioni!");
        }

        h.avanzaStato();
        hackathonRepo.save(h);
    }

    public void avviaHackathon(Long id, Long organizzatoreId) {
        Hackathon h = hackathonRepo.findById(id).orElseThrow();
        // CONTROLLO DI SICUREZZA (Autorizzazione)
        if (!h.getOrganizzatore().getId().equals(organizzatoreId)) {
            throw new RuntimeException("ACCESSO NEGATO: Solo l'organizzatore dell'evento può avanzare lo stato!");
        }

        h.avanzaStato();
        hackathonRepo.save(h);
    }
    public void inValutazione(Long id, Long organizzatoreId) {
        Hackathon h = hackathonRepo.findById(id).orElseThrow();

        if (!h.getOrganizzatore().getId().equals(organizzatoreId)) {
            throw new RuntimeException("ACCESSO NEGATO: Solo l'organizzatore dell'evento può avanzare lo stato!");
        }

        h.avanzaStato();
        hackathonRepo.save(h);
    }

    public void concludiHackathon(Long id,Long organizzatoreId) {
        Hackathon h = hackathonRepo.findById(id).orElseThrow();
        if (!h.getOrganizzatore().getId().equals(organizzatoreId)) {
            throw new RuntimeException("ACCESSO NEGATO: Solo l'organizzatore dell'evento può concludere l'evento!");
        }
        hackathonRepo.save(h);
    }

    public List<Hackathon> getAllHackathon() {
        return hackathonRepo.findAll();
    }


}