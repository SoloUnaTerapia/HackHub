package com.hackhub.hackhub.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
/**
 * Entità principale del dominio che rappresenta l'account fisico di una persona.
 * In ottica UML, questa singola entità può ricoprire dinamicamente diversi "Attori"
 * (Organizzatore, Giudice, Mentore, Membro Team) in base alle relazioni che
 * instaura con le altre entità (es. Hackathon, Team)
 */
@Entity
public class Utente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment
    private Long id;

    private String nome;
    //vincolo di unicità: non possono esistere due utenti con la stessa email
    @Column(unique = true, nullable = false)
    private String email;

    private String password;


    @ManyToOne
    @JoinColumn(name = "team_id")
    @JsonIgnore
    private Team team;


    public Utente() {}

    public Utente(String nome, String email, String password) {
        this.nome = nome;
        this.email = email;
        this.password = password;
    }


    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public Team getTeam() { return team; }
    public void setTeam(Team team) { this.team = team; }
}