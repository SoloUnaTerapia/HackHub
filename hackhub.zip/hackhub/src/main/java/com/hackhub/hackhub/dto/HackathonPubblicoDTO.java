package com.hackhub.hackhub.dto;

import java.time.LocalDateTime;

public class HackathonPubblicoDTO {
    private Long id;
    private String titolo;
    private String luogo;
    private double premio;
    private int maxTeamSize;
    private LocalDateTime dataInizio;
    private LocalDateTime dataFine;
    private LocalDateTime scadenzaIscrizioni;
    private String stato;
    private String nomeOrganizzatore;

    public HackathonPubblicoDTO(Long id, String titolo,
                                 String luogo, double premio, int maxTeamSize, LocalDateTime dataInizio,
                                LocalDateTime dataFine, LocalDateTime scadenzaIscrizioni, String stato, String nomeOrganizzatore) {
        this.id = id;
        this.titolo = titolo;
        this.luogo = luogo;
        this.premio = premio;
        this.maxTeamSize = maxTeamSize;
        this.dataInizio = dataInizio;
        this.dataFine = dataFine;
        this.scadenzaIscrizioni = scadenzaIscrizioni;
        this.stato = stato;
        this.nomeOrganizzatore = nomeOrganizzatore;
    }


    public Long getId() { return id; }
    public String getTitolo() { return titolo; }
    public String getLuogo() { return luogo; }
    public double getPremio() { return premio; }
    public int getMaxTeamSize() { return maxTeamSize; }
    public LocalDateTime getDataInizio() { return dataInizio; }
    public LocalDateTime getDataFine() { return dataFine; }
    public LocalDateTime getScadenzaIscrizioni() { return scadenzaIscrizioni; }
    public String getStato() { return stato; }
    public String getNomeOrganizzatore() { return nomeOrganizzatore; }
}