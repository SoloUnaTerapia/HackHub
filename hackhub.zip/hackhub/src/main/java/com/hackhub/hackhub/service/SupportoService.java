package com.hackhub.hackhub.service;

import com.hackhub.hackhub.adapter.CalendarService;
import com.hackhub.hackhub.dto.GestioneCallDTO;
import com.hackhub.hackhub.model.*;
import com.hackhub.hackhub.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class SupportoService {

    @Autowired private RichiestaSupportoRepository supportoRepo;
    @Autowired private UtenteRepository utenteRepo;
    @Autowired private TeamRepository teamRepo;
    @Autowired private HackathonRepository hackRepo;
    @Autowired private CalendarService calendarService; // INIEZIONE DELL'ADAPTER!


    public RichiestaSupporto chiediAiuto(Long teamId, Long mentoreId, Long hackId, String messaggio) {
        Team t = teamRepo.findById(teamId).orElseThrow();
        Utente m = utenteRepo.findById(mentoreId).orElseThrow();
        Hackathon h = hackRepo.findById(hackId).orElseThrow();


        if (!h.getMentori().contains(m)) {
            throw new RuntimeException("L'utente selezionato non è un mentore di questo evento!");
        }

        RichiestaSupporto r = new RichiestaSupporto(messaggio, t, m, h);
        return supportoRepo.save(r);
    }


    public String programmaCall(GestioneCallDTO dto) {
        RichiestaSupporto r = supportoRepo.findById(dto.getRichiestaId()).orElseThrow();


        if (!r.getMentore().getId().equals(dto.getMentoreId())) {
            throw new RuntimeException("Sicurezza: Non sei autorizzato a gestire questa richiesta!");
        }

        //fissiamo per domani a questora
        LocalDateTime orario = LocalDateTime.now().plusDays(1);

        //adapter
        String link = calendarService.prenotaSlot(r.getMentore().getEmail(), r.getTeam().getLeader().getEmail(), orario);


        r.impostaCall(orario, link);
        supportoRepo.save(r);

        return link;
    }

    public java.util.List<com.hackhub.hackhub.dto.RichiestaSupportoInfoDTO> getRichiesteMentore(Long mentoreId) {
        return supportoRepo.findAll().stream()
                .filter(r -> r.getMentore().getId().equals(mentoreId))
                .map(r -> new com.hackhub.hackhub.dto.RichiestaSupportoInfoDTO(
                        r.getId(),
                        r.getTeam().getNome(),
                        r.getMessaggioProblema(),
                        r.getStato().name(),
                        r.getOrarioCall() != null ? r.getOrarioCall().toString() : "non ancora fissata",
                        r.getLinkMeet() != null ? r.getLinkMeet() : "nessun link"
                ))
                .collect(java.util.stream.Collectors.toList());
    }
}
