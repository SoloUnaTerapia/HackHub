package com.hackhub.hackhub.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
/**
 * Rappresenta un task/una sfida definita dall'Organizzatore
 * Permette di disaccoppiare la Sottomissione dall'Hackathon
 */
@Entity
public class Traccia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titolo;
    private String descrizione;

    @ManyToOne
    @JoinColumn(name = "hackathon_id")
    @JsonIgnore
    private Hackathon hackathon;

    public Traccia() {}

    public Traccia(String titolo, String descrizione, Hackathon hackathon) {
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.hackathon = hackathon;
    }


    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitolo() { return titolo; }
    public void setTitolo(String titolo) { this.titolo = titolo; }
    public String getDescrizione() { return descrizione; }
    public void setDescrizione(String descrizione) { this.descrizione = descrizione; }
    public Hackathon getHackathon() { return hackathon; }
    public void setHackathon(Hackathon hackathon) { this.hackathon = hackathon; }
}