package com.hackhub.hackhub.dto;

import java.time.LocalDateTime;

public class CreaHackathonDTO {
    private String titolo;
    private String regolamento;
    private String luogo;
    private double premio;
    private int maxTeamSize;
    private Long organizzatoreId;
    private LocalDateTime scadenzaIscrizioni;
    private LocalDateTime dataInizio;
    private LocalDateTime dataFine;

    // Aggiungi tutti i Getter e Setter!
    public String getTitolo() { return titolo; } public void setTitolo(String t) { titolo = t; }
    public String getRegolamento() { return regolamento; } public void setRegolamento(String r) { regolamento = r; }
    public String getLuogo() { return luogo; } public void setLuogo(String l) { luogo = l; }
    public double getPremio() { return premio; } public void setPremio(double p) { premio = p; }
    public int getMaxTeamSize() { return maxTeamSize; } public void setMaxTeamSize(int m) { maxTeamSize = m; }
    public Long getOrganizzatoreId() { return organizzatoreId; } public void setOrganizzatoreId(Long id) { organizzatoreId = id; }
    public LocalDateTime getScadenzaIscrizioni() { return scadenzaIscrizioni; }
    public void setScadenzaIscrizioni(LocalDateTime scadenzaIscrizioni) { this.scadenzaIscrizioni = scadenzaIscrizioni; }
    public LocalDateTime getDataInizio() { return dataInizio; }
    public void setDataInizio(LocalDateTime dataInizio) { this.dataInizio = dataInizio; }
    public LocalDateTime getDataFine() { return dataFine; }
    public void setDataFine(LocalDateTime dataFine) { this.dataFine = dataFine; }

}