package com.hackhub.hackhub.adapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/**
 * [PATTERN ADAPTER] - Ruolo: ADAPTER
 *
 * Traduce la nostra chiamata standard (erogaPremio) in una chiamata
 * compatibile con le specifiche dell'Adaptee (PayPalExternalApi).
 */
@Service
public class PayPalAdapter implements PaymentService {

    //l'Adapter "contiene" un'istanza dell'Adaptee
    @Autowired
    private PayPalExternalApi payPalApi;

    @Override
    public void erogaPremio(String emailVincitore, double importo) {
        System.out.println("🔄 [ADAPTER] Traduzione della richiesta di premio per PayPal...");


        boolean esito = payPalApi.sendMoneyTransaction(emailVincitore, "EUR", importo);

        if (!esito) {
            throw new RuntimeException("Errore dal sistema bancario esterno!");
        }
    }
}
