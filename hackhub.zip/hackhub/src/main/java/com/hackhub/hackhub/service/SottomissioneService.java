package com.hackhub.hackhub.service;

import com.hackhub.hackhub.dto.CreaSottomissioneDTO;
import com.hackhub.hackhub.dto.CreaTracciaDTO;
import com.hackhub.hackhub.model.*;
import com.hackhub.hackhub.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class SottomissioneService {

    @Autowired private TracciaRepository tracciaRepo;
    @Autowired private SottomissioneRepository sottomissioneRepo;
    @Autowired private HackathonRepository hackathonRepo;
    @Autowired private UtenteRepository utenteRepo;

    // --- L'ORGANIZZATORE CREA LA TRACCIA ---
    public Traccia creaTraccia(CreaTracciaDTO dto) {
        Hackathon h = hackathonRepo.findById(dto.getHackathonId())
                .orElseThrow(() -> new RuntimeException("Hackathon non trovato!"));

        Traccia t = new Traccia(dto.getTitolo(), dto.getDescrizione(), h);
        return tracciaRepo.save(t);
    }

    // --- IL TEAM INVIA O AGGIORNA IL LAVORO ---
    @Transactional
    public Sottomissione gestisciSottomissione(CreaSottomissioneDTO dto) {
        Traccia traccia = tracciaRepo.findById(dto.getTracciaId())
                .orElseThrow(() -> new RuntimeException("Traccia non trovata!"));

        Utente autore = utenteRepo.findById(dto.getUtenteId())
                .orElseThrow(() -> new RuntimeException("Utente non trovato!"));

        Team team = autore.getTeam();
        if (team == null) {
            throw new RuntimeException("Devi far parte di un team per inviare un progetto!");
        }

        Hackathon h = traccia.getHackathon();

        // 1. PATTERN STATE: Controlla se l'Hackathon è "IN_CORSO"
        h.uploadSottomissione();

        // 2. Controllo Iscrizione
        if (!h.getTeamsIscritti().contains(team)) {
            throw new RuntimeException("Il tuo team non è iscritto a questo Hackathon!");
        }

        // 3. Logica: Crea o Aggiorna
        Optional<Sottomissione> sottomissioneEsistente = sottomissioneRepo.findByTeamAndTraccia(team, traccia);

        Sottomissione sottomissione;
        if (sottomissioneEsistente.isPresent()) {
            sottomissione = sottomissioneEsistente.get();

            // Se l'aveva già marcata come completata in passato, blocco tutto
            if (sottomissione.getStato() == Sottomissione.StatoSottomissione.COMPLETATA) {
                throw new RuntimeException("Hai già effettuato la consegna definitiva! Non puoi più modificare.");
            }

            // Aggiorno
            sottomissione.lavora(dto.getTestoSoluzione(), dto.getUrlProgetto(), autore);
        } else {
            // Creo nuova
            sottomissione = new Sottomissione(team, traccia, autore);
            sottomissione.lavora(dto.getTestoSoluzione(), dto.getUrlProgetto(), autore);
        }

        // 4. Se spunta la casella "Definitiva", chiudo la sottomissione
        if (dto.isDefinitiva()) {
            sottomissione.completa();
        }

        return sottomissioneRepo.save(sottomissione);
    }
}