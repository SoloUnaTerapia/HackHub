package com.hackhub.hackhub.service;

import com.hackhub.hackhub.dto.CreaSottomissioneDTO;
import com.hackhub.hackhub.dto.CreaTracciaDTO;
import com.hackhub.hackhub.model.*;
import com.hackhub.hackhub.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class SottomissioneService {

    @Autowired private TracciaRepository tracciaRepo;
    @Autowired private SottomissioneRepository sottomissioneRepo;
    @Autowired private HackathonRepository hackathonRepo;
    @Autowired private UtenteRepository utenteRepo;


    public Traccia creaTraccia(CreaTracciaDTO dto) {
        Hackathon h = hackathonRepo.findById(dto.getHackathonId())
                .orElseThrow(() -> new RuntimeException("Hackathon non trovato!"));
        if (!h.getOrganizzatore().getId().equals(dto.getCreatoreId())) {
            throw new RuntimeException("ACCESSO NEGATO: Solo l'Organizzatore può creare le tracce per questo evento!");
        }

        Traccia t = new Traccia(dto.getTitolo(), dto.getDescrizione(), h);
        return tracciaRepo.save(t);
    }


    @Transactional
    public Sottomissione gestisciSottomissione(CreaSottomissioneDTO dto) {
        Traccia traccia = tracciaRepo.findById(dto.getTracciaId())
                .orElseThrow(() -> new RuntimeException("Traccia non trovata!"));

        Utente autore = utenteRepo.findById(dto.getUtenteId())
                .orElseThrow(() -> new RuntimeException("Utente non trovato!"));

        Team team = autore.getTeam();
        if (team == null) {
            throw new RuntimeException("Devi far parte di un team per inviare un progetto!");
        }

        Hackathon h = traccia.getHackathon();


        h.uploadSottomissione();


        if (!h.getTeamsIscritti().contains(team)) {
            throw new RuntimeException("Il tuo team non è iscritto a questo Hackathon!");
        }


        Optional<Sottomissione> sottomissioneEsistente = sottomissioneRepo.findByTeamAndTraccia(team, traccia);

        Sottomissione sottomissione;
        if (sottomissioneEsistente.isPresent()) {
            sottomissione = sottomissioneEsistente.get();


            if (sottomissione.getStato() == Sottomissione.StatoSottomissione.COMPLETATA) {
                throw new RuntimeException("Hai già effettuato la consegna definitiva! Non puoi più modificare.");
            }


            sottomissione.lavora(dto.getTestoSoluzione(), dto.getUrlProgetto(), autore);
        } else {

            sottomissione = new Sottomissione(team, traccia, autore);
            sottomissione.lavora(dto.getTestoSoluzione(), dto.getUrlProgetto(), autore);
        }


        if (dto.isDefinitiva()) {
            sottomissione.completa();
        }

        return sottomissioneRepo.save(sottomissione);
    }



    public java.util.List<com.hackhub.hackhub.dto.SottomissioneInfoDTO> getSottomissioniGiudice(Long hackathonId, Long giudiceId) {

        Hackathon h = hackathonRepo.findById(hackathonId)
                .orElseThrow(() -> new RuntimeException("Hackathon non trovato"));


        if (h.getGiudice() == null || !h.getGiudice().getId().equals(giudiceId)) {
            throw new RuntimeException("ACCESSO NEGATO: Solo il Giudice assegnato può visualizzare le sottomissioni!");
        }


        return sottomissioneRepo.findAll().stream()
                .filter(s -> s.getTraccia().getHackathon().getId().equals(hackathonId))
                .map(s -> new com.hackhub.hackhub.dto.SottomissioneInfoDTO(
                        s.getId(),
                        s.getTeam().getNome(),
                        s.getTraccia().getTitolo(),
                        s.getUrlProgetto(),
                        s.getStato().name()
                ))
                .collect(java.util.stream.Collectors.toList());
    }
}