package com.hackhub.hackhub.repository;

import com.hackhub.hackhub.model.Sottomissione;
import com.hackhub.hackhub.model.Team;
import com.hackhub.hackhub.model.Traccia;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface SottomissioneRepository extends JpaRepository<Sottomissione, Long> {

    Optional<Sottomissione> findByTeamAndTraccia(Team team, Traccia traccia);
}