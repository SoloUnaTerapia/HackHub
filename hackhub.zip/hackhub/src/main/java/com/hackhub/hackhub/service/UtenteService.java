package com.hackhub.hackhub.service;

import com.hackhub.hackhub.dto.UtenteInfoDTO;
import com.hackhub.hackhub.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UtenteService {

    @Autowired
    private UtenteRepository utenteRepository;

    public List<UtenteInfoDTO> getUtenti() {

        return utenteRepository.findAll().stream().map(utente -> {


            String teamName = (utente.getTeam() != null) ? utente.getTeam().getNome() : "Nessun Team";


            return new UtenteInfoDTO(
                    utente.getId(),
                    utente.getNome(),
                    utente.getEmail(),
                    teamName
            );
        }).collect(java.util.stream.Collectors.toList());
    }
}
