package com.hackhub.hackhub.model;

import jakarta.persistence.*;
/**
 * Entità che salva il giudizio espresso da un Giudice.
 * Incapsula il punteggio, che sarà poi aggregato dal ProclamazioneService
 * per determinare il vincitore.
 */
@Entity
public class Valutazione {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private int punteggio;

    @Column(length = 1000)
    private String giudizioTestuale;


    @ManyToOne
    @JoinColumn(name = "sottomissione_id")
    private Sottomissione sottomissione;

    @ManyToOne
    @JoinColumn(name = "giudice_id")
    private Utente giudice;

    public Valutazione() {}

    public Valutazione(int punteggio, String giudizioTestuale, Sottomissione sottomissione, Utente giudice) {
        this.punteggio = punteggio;
        this.giudizioTestuale = giudizioTestuale;
        this.sottomissione = sottomissione;
        this.giudice = giudice;
    }


    public Long getId() { return id; }
    public int getPunteggio() { return punteggio; }
    public void setPunteggio(int punteggio) { this.punteggio = punteggio; }
    public String getGiudizioTestuale() { return giudizioTestuale; }
    public void setGiudizioTestuale(String giudizio) { this.giudizioTestuale = giudizio; }
    public Sottomissione getSottomissione() { return sottomissione; }
    public Utente getGiudice() { return giudice; }
}
