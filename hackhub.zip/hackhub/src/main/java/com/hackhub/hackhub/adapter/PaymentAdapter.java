package com.hackhub.hackhub.adapter;
import org.springframework.stereotype.Service;

@Service // Fondamentale in Spring per poterlo iniettare!
public class PaymentAdapter implements PaymentService {
    @Override
    public boolean erogaPremio(String emailVincitore, double importo) {
        System.out.println("💰 [SISTEMA BANCARIO SIMULATO] 💰");
        System.out.println("Erogazione di €" + importo + " a favore di: " + emailVincitore);
        System.out.println("Transazione Completata con Successo!");
        return true;
    }
}