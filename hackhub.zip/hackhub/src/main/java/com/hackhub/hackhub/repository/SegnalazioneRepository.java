package com.hackhub.hackhub.repository;

public interface SegnalazioneRepository extends org.springframework.data.jpa.repository.JpaRepository<com.hackhub.hackhub.model.Segnalazione, Long> {}