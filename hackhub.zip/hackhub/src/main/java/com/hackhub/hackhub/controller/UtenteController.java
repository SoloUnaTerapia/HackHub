package com.hackhub.hackhub.controller;

import com.hackhub.hackhub.service.AuthService;
import com.hackhub.hackhub.service.UtenteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/utenti")
public class UtenteController {
    @Autowired
    private UtenteService utenteService;

    @GetMapping("/lista")
    public ResponseEntity<?> getListaUtenti() {
        return ResponseEntity.ok(utenteService.getUtenti());
    }
}
