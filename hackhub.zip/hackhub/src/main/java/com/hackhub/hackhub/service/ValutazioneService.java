package com.hackhub.hackhub.service;

import com.hackhub.hackhub.dto.CreaValutazioneDTO;
import com.hackhub.hackhub.model.*;
import com.hackhub.hackhub.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ValutazioneService {

    @Autowired private ValutazioneRepository valutazioneRepo;
    @Autowired private SottomissioneRepository sottomissioneRepo;
    @Autowired private UtenteRepository utenteRepo;

    public Valutazione aggiungiValutazione(CreaValutazioneDTO dto) {


        if (dto.getPunteggio() < 0 || dto.getPunteggio() > 10) {
            throw new RuntimeException("Errore: Il punteggio deve essere compreso tra 0 e 10!");
        }


        Sottomissione sottomissione = sottomissioneRepo.findById(dto.getSottomissioneId())
                .orElseThrow(() -> new RuntimeException("Sottomissione non trovata"));
        Utente utente = utenteRepo.findById(dto.getGiudiceId())
                .orElseThrow(() -> new RuntimeException("Giudice non trovato"));


        Hackathon h = sottomissione.getTraccia().getHackathon();


        h.valutaSottomissione();


        if (h.getGiudice() == null || !h.getGiudice().getId().equals(utente.getId())) {
            throw new RuntimeException("Errore di Sicurezza: Non sei il giudice assegnato a questo Hackathon!");
        }


        Valutazione v = new Valutazione(dto.getPunteggio(), dto.getGiudizio(), sottomissione, utente);
        return valutazioneRepo.save(v);
    }
}