package com.hackhub.hackhub.dto;

public class SottomissioneInfoDTO {
    private Long sottomissioneId;
    private String nomeTeam;
    private String titoloTraccia;
    private String urlProgetto;
    private String stato;

    public SottomissioneInfoDTO(Long sottomissioneId, String nomeTeam, String titoloTraccia, String urlProgetto, String stato) {
        this.sottomissioneId = sottomissioneId;
        this.nomeTeam = nomeTeam;
        this.titoloTraccia = titoloTraccia;
        this.urlProgetto = urlProgetto;
        this.stato = stato;
    }

    // Getter
    public Long getSottomissioneId() { return sottomissioneId; }
    public String getNomeTeam() { return nomeTeam; }
    public String getTitoloTraccia() { return titoloTraccia; }
    public String getUrlProgetto() { return urlProgetto; }
    public String getStato() { return stato; }
}