package com.hackhub.hackhub.dto;

public class UtenteInfoDTO {
    private Long id;
    private String nome;
    private String email;
    private String nomeTeam;

    public UtenteInfoDTO(Long id, String nome, String email, String nomeTeam) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.nomeTeam = nomeTeam;
    }


    public Long getId() { return id; }
    public String getNome() { return nome; }
    public String getEmail() { return email; }
    public String getNomeTeam() { return nomeTeam; }
}
