package com.hackhub.hackhub.service;

import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.repository.HackathonRepository;
import com.hackhub.hackhub.state.TipoStato;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TimeService {

    @Autowired
    private HackathonService hackathonService; // Uso il Service, non il Repo, per riusare la logica!

    @Autowired
    private HackathonRepository hackathonRepo;

    // Esegue ogni 10 secondi per reattività durante la demo
    @Scheduled(fixedRate = 10000)
    @Transactional
    public void controllaScadenzeHackathon() {
        LocalDateTime adesso = LocalDateTime.now();
        List<Hackathon> tutti = hackathonRepo.findAll();

        for (Hackathon h : tutti) {
            // Seleziona solo quelli in Iscrizione
            if (h.getTipoStato() == TipoStato.IN_ISCRIZIONE) {
                // Se la data di scadenza è passata...
                if (adesso.isAfter(h.getScadenzaIscrizioni())) {
                    System.out.println(" [TEMPO] Scadenza iscrizioni per '" + h.getTitolo() + "'. Avvio gara!");
                    // Riutilizzo il metodo manuale che avevi già fatto!
                    hackathonService.avviaHackathon(h.getId(), h.getOrganizzatore().getId());
                }
            }
            // Seleziona solo quelli In Corso
            else if (h.getTipoStato() == TipoStato.IN_CORSO) {
                // Se la data di fine è passata...
                if (adesso.isAfter(h.getDataFine())) {
                    System.out.println("⏰ [TEMPO] Fine gara per '" + h.getTitolo() + "'. Inizio valutazioni!");
                    // Riutilizzo il metodo manuale!
                    hackathonService.inValutazione(h.getId(), h.getOrganizzatore().getId());
                }
            }
        }
    }
}
