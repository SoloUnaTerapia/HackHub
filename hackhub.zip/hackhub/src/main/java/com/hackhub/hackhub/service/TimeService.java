package com.hackhub.hackhub.service;

import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.repository.HackathonRepository;
import com.hackhub.hackhub.state.TipoStato;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TimeService {

    @Autowired
    private HackathonService hackathonService;

    @Autowired
    private HackathonRepository hackathonRepo;


    @Scheduled(fixedRate = 10000)
    @Transactional
    public void controllaScadenzeHackathon() {
        LocalDateTime adesso = LocalDateTime.now();
        List<Hackathon> tutti = hackathonRepo.findAll();

        for (Hackathon h : tutti) {

            if (h.getTipoStato() == TipoStato.IN_ISCRIZIONE) {

                if (adesso.isAfter(h.getScadenzaIscrizioni())) {
                    System.out.println("Scadenza iscrizioni per '" + h.getTitolo() + "'. avvio gara");

                    hackathonService.avviaHackathon(h.getId(), h.getOrganizzatore().getId());
                }
            }

            else if (h.getTipoStato() == TipoStato.IN_CORSO) {

                if (adesso.isAfter(h.getDataFine())) {
                    System.out.println("Fine gara per '" + h.getTitolo() + "'. inizio valutazioni");

                    hackathonService.inValutazione(h.getId(), h.getOrganizzatore().getId());
                }
            }
        }
    }
}
