package com.hackhub.hackhub.repository;


import com.hackhub.hackhub.model.Utente;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;


public interface UtenteRepository extends JpaRepository<Utente, Long> {

    Optional<Utente> findByEmail(String email);
}