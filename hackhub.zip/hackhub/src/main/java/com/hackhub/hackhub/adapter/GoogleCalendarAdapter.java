package com.hackhub.hackhub.adapter;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;


/**
 * [PATTERN ADAPTER] - Ruolo: ADAPTER
 *
 * Questa classe concreta implementa la nostra interfaccia (Target) e si occupa di
 * "tradurre" la richiesta in comandi comprensibili dall'API di Google Calendar
 * Se in futuro cambiassimo provider (es. Microsoft Teams), basterà creare un
 * nuovo Adapter senza dover toccare la logica del SupportoService
 */

@Service
public class GoogleCalendarAdapter implements CalendarService {
    @Override
    public String prenotaSlot(String emailMentore, String emailTeam, LocalDateTime orario) {
        System.out.println("[GOOGLE CALENDAR API]");
        System.out.println("Creazione evento per il: " + orario);
        System.out.println("Partecipanti: " + emailMentore + " e " + emailTeam);
        return "https://meet.google.com/hack-" + System.nanoTime();
    }
}