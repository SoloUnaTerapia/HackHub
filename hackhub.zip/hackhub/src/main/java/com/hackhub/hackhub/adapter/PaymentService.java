package com.hackhub.hackhub.adapter;

public interface PaymentService {
    boolean erogaPremio(String emailVincitore, double importo);
}