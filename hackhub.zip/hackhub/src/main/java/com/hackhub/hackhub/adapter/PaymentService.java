package com.hackhub.hackhub.adapter;
/**
 * [PATTERN ADAPTER] - Ruolo: TARGET
 *
 * Interfaccia standard per l'erogazione dei premi in denaro.
 * Il nostro ProclamazioneService chiama solo questa interfaccia, ignorando
 * totalmente i dettagli implementativi delle banche o dei servizi esterni
 */
public interface PaymentService {

    /**
     * Eroga l'importo del premio al vincitore
     *
     * @param emailVincitore L'account email a cui accreditare i fondi
     * @param importo La cifra del premio da erogare
     */
    void erogaPremio(String emailVincitore, double importo);
}