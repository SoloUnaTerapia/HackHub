package com.hackhub.hackhub.state;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;
import com.hackhub.hackhub.model.Utente;

public interface HackathonState {
    void iscriviTeam(Hackathon h, Team t);
    void avanzaStato(Hackathon h);
    void uploadSottomissione(Hackathon h);
    void valutaSottomissione(Hackathon h);
    void proclamaVincitore(Hackathon h);
    void assegnaGiudice(Hackathon h, Utente u);
}