package com.hackhub.hackhub.model;
import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Team {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String nome;

    // Un team ha un solo leader
    @OneToOne
    @JoinColumn(name = "leader_id")
    private Utente leader;

    // Un team ha molti membri. "mappedBy" indica che la relazione è gestita dall'utente
    @OneToMany(mappedBy = "team", cascade = CascadeType.ALL)
    private List<Utente> membri = new ArrayList<>();

    public Team() {}

    public Team(String nome, Utente leader) {
        this.nome = nome;
        this.leader = leader;
    }
    @ManyToOne
    @JoinColumn(name = "hackathon_id")
    private Hackathon hackathon;

    public Hackathon getHackathon() { return hackathon; }
    public void setHackathon(Hackathon hackathon) { this.hackathon = hackathon; }
    // --- GETTER E SETTER ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public Utente getLeader() { return leader; }
    public void setLeader(Utente leader) { this.leader = leader; }
    public List<Utente> getMembri() { return membri; }
    public void setMembri(List<Utente> membri) { this.membri = membri; }
}