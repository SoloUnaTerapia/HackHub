package com.hackhub.hackhub.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Traccia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titolo;
    private String descrizione;

    @ManyToOne
    @JoinColumn(name = "hackathon_id")
    @JsonIgnore // Evita loop infiniti con Postman
    private Hackathon hackathon;

    public Traccia() {}

    public Traccia(String titolo, String descrizione, Hackathon hackathon) {
        this.titolo = titolo;
        this.descrizione = descrizione;
        this.hackathon = hackathon;
    }

    // --- GETTER E SETTER ---
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitolo() { return titolo; }
    public void setTitolo(String titolo) { this.titolo = titolo; }
    public String getDescrizione() { return descrizione; }
    public void setDescrizione(String descrizione) { this.descrizione = descrizione; }
    public Hackathon getHackathon() { return hackathon; }
    public void setHackathon(Hackathon hackathon) { this.hackathon = hackathon; }
}