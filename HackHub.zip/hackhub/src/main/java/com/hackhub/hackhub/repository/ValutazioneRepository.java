package com.hackhub.hackhub.repository;
import com.hackhub.hackhub.model.Valutazione;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ValutazioneRepository extends JpaRepository<Valutazione, Long> {
}