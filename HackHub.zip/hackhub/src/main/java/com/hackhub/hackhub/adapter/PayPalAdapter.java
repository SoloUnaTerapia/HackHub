package com.hackhub.hackhub.adapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service // Spring inietterà questo Adapter nel nostro ProclamazioneService
public class PayPalAdapter implements PaymentService {

    // L'Adapter CONTIENE l'Adaptee (Composizione)
    @Autowired
    private PayPalExternalApi payPalApi;

    @Override
    public void erogaPremio(String emailVincitore, double importo) {
        System.out.println("🔄 [ADAPTER] Traduzione della richiesta di premio per PayPal...");

        // TRADUZIONE: Chiamo il metodo esterno adattando i parametri!
        // Aggiungo la valuta "EUR" che la nostra interfaccia non prevedeva.
        boolean esito = payPalApi.sendMoneyTransaction(emailVincitore, "EUR", importo);

        if (!esito) {
            throw new RuntimeException("Errore dal sistema bancario esterno!");
        }
    }
}
