package com.hackhub.hackhub.adapter;

public interface PaymentService {
    void erogaPremio(String emailVincitore, double importo);
}