package com.hackhub.hackhub.controller;

import com.hackhub.hackhub.dto.GestioneCallDTO;
import com.hackhub.hackhub.service.SupportoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/supporto")
public class SupportoController {

    @Autowired private SupportoService supportoService;

    // Semplificato per test rapido
    @PostMapping("/chiedi")
    public ResponseEntity<?> chiedi(@RequestParam Long teamId, @RequestParam Long mentoreId, @RequestParam Long hackId, @RequestParam String msg) {
        return ResponseEntity.ok(supportoService.chiediAiuto(teamId, mentoreId, hackId, msg).getId());
    }

    @PostMapping("/fissa-call")
    public ResponseEntity<?> fissaCall(@RequestBody GestioneCallDTO dto) {
        try {
            String link = supportoService.programmaCall(dto);
            return ResponseEntity.ok("Call Fissata! Ecco il link: " + link);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}