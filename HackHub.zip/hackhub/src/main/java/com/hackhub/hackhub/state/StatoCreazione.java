package com.hackhub.hackhub.state;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;
import com.hackhub.hackhub.model.Utente;

public class StatoCreazione implements HackathonState {
    @Override
    public void iscriviTeam(Hackathon h, Team t) {
        throw new RuntimeException("Errore: Hackathon non ancora aperto alle iscrizioni!");
    }

    @Override
    public void avanzaStato(Hackathon h) {
        // 1. Controllo Giudice
        if (h.getGiudice() == null) {
            throw new RuntimeException("Operazione bloccata: Devi assegnare un Giudice prima di aprire le iscrizioni!");
        }

        // 2. Controllo Mentori (Almeno 1)
        if (h.getMentori() == null || h.getMentori().isEmpty()) {
            throw new RuntimeException("Operazione bloccata: Devi assegnare almeno un Mentore prima di aprire le iscrizioni!");
        }

        // Se i controlli passano, procediamo col cambio di stato
        h.setTipoStato(TipoStato.IN_ISCRIZIONE);
        h.setStatoComportamento(new StatoInIscrizione());

        System.out.println("STATO: Requisiti staff verificati. L'Hackathon è ora IN_ISCRIZIONE.");
    }

    @Override
    public void uploadSottomissione(Hackathon h) {
        throw new RuntimeException("Errore: Non puoi inviare lavori adesso. L'Hackathon non è In Corso!");
    }

    @Override
    public void valutaSottomissione(Hackathon h) {
        throw new RuntimeException("Errore: non è possibile valutare; L'evento è in Creazione.");

    }

    @Override
    public void proclamaVincitore(Hackathon h) {
        throw new RuntimeException("Errore: non è possibile proclamare il vincitore; L'evento è in creazione.");

    }

    @Override
    public void assegnaGiudice(Hackathon h, Utente u) {
        // LUCE VERDE! In creazione si può fare. Non lanciamo eccezioni.
        System.out.println("STATO: Permesso accordato per assegnare il giudice.");
    }
}