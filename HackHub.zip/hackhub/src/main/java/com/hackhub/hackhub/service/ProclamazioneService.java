package com.hackhub.hackhub.service;

import com.hackhub.hackhub.adapter.PaymentService;
import com.hackhub.hackhub.model.*;
import com.hackhub.hackhub.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProclamazioneService {

    @Autowired private HackathonRepository hackathonRepo;
    @Autowired private SottomissioneRepository sottomissioneRepo;
    @Autowired private ValutazioneRepository valutazioneRepo;
    @Autowired private PaymentService paymentService; // L'Adapter!

    @Transactional
    public Team proclamaVincitore(Long hackathonId, Long organizzatoreId) {
        Hackathon h = hackathonRepo.findById(hackathonId)
                .orElseThrow(() -> new RuntimeException("Hackathon non trovato"));

        // 1. Controllo Sicurezza: Solo l'organizzatore può proclamare!
        if (!h.getOrganizzatore().getId().equals(organizzatoreId)) {
            throw new RuntimeException("Errore: Solo l'Organizzatore può proclamare il vincitore!");
        }

        // 2. Controllo Stato: Si può proclamare solo "IN_VALUTAZIONE"
        // (Se non è in valutazione, il pattern State lancerà un'eccezione qui)
        h.proclamaVincitore();

        // 3. Recupero tutte le sottomissioni e le valutazioni di questo specifico evento
        List<Sottomissione> sottomissioni = sottomissioneRepo.findAll().stream()
                .filter(s -> s.getTraccia().getHackathon().getId().equals(hackathonId))
                .collect(Collectors.toList());

        List<Valutazione> valutazioni = valutazioneRepo.findAll().stream()
                .filter(v -> v.getSottomissione().getTraccia().getHackathon().getId().equals(hackathonId))
                .collect(Collectors.toList());

        // 4. REGOLA DI BUSINESS: Tutte le sottomissioni sono state giudicate?
        if (sottomissioni.isEmpty()) {
            throw new RuntimeException("Impossibile proclamare: Nessun team ha consegnato un lavoro.");
        }
        if (sottomissioni.size() > valutazioni.size()) {
            throw new RuntimeException("Impossibile proclamare: Il giudice non ha ancora valutato tutti i lavori!");
        }

        // 5. Calcolo del Vincitore (Quello col punteggio massimo)
        Valutazione maxValutazione = valutazioni.stream()
                .max(Comparator.comparingInt(Valutazione::getPunteggio))
                .orElseThrow(() -> new RuntimeException("Errore nel calcolo dei voti"));

        Team teamVincitore = maxValutazione.getSottomissione().getTeam();

        // 6. Salvataggio del vincitore
        h.setVincitore(teamVincitore);
        hackathonRepo.save(h);

        // 7. Erogazione del Premio (Tramite Adapter Esterno)
        paymentService.erogaPremio(teamVincitore.getLeader().getEmail(), h.getPremio());

        return teamVincitore;
    }
}
