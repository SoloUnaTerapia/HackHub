package com.hackhub.hackhub.repository;


import com.hackhub.hackhub.model.Team;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TeamRepository extends JpaRepository<Team, Long> {
}
