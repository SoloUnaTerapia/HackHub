package com.hackhub.hackhub.controller;

import com.hackhub.hackhub.service.AuthService;
import com.hackhub.hackhub.service.UtenteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;// Endpoint per vedere chi c'è sulla piattaforma (utile per Organizzatori e Leader)
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // Dice a Spring che questo risponde alle chiamate web
@RequestMapping("/api/utenti") // L'URL base per questo controller
public class UtenteController {
    @Autowired
    private UtenteService utenteService;

    @GetMapping("/lista")
    public ResponseEntity<?> getListaUtenti() {
        return ResponseEntity.ok(utenteService.getUtenti());
    }
}
