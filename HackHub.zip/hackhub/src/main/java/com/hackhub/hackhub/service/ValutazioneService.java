package com.hackhub.hackhub.service;

import com.hackhub.hackhub.dto.CreaValutazioneDTO;
import com.hackhub.hackhub.model.*;
import com.hackhub.hackhub.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ValutazioneService {

    @Autowired private ValutazioneRepository valutazioneRepo;
    @Autowired private SottomissioneRepository sottomissioneRepo;
    @Autowired private UtenteRepository utenteRepo;

    public Valutazione aggiungiValutazione(CreaValutazioneDTO dto) {

        // 1. Validazione del voto (Regola di business da specifica: 0-10)
        if (dto.getPunteggio() < 0 || dto.getPunteggio() > 10) {
            throw new RuntimeException("Errore: Il punteggio deve essere compreso tra 0 e 10!");
        }

        // 2. Recupero oggetti
        Sottomissione sottomissione = sottomissioneRepo.findById(dto.getSottomissioneId())
                .orElseThrow(() -> new RuntimeException("Sottomissione non trovata"));
        Utente utente = utenteRepo.findById(dto.getGiudiceId())
                .orElseThrow(() -> new RuntimeException("Giudice non trovato"));

        // Recupero l'Hackathon passando per la traccia
        Hackathon h = sottomissione.getTraccia().getHackathon();

        // 3. PATTERN STATE: Si può valutare ora?
        h.valutaSottomissione();

        // 4. CONTROLLO SICUREZZA: Sei tu il giudice?
        if (h.getGiudice() == null || !h.getGiudice().getId().equals(utente.getId())) {
            throw new RuntimeException("Errore di Sicurezza: Non sei il giudice assegnato a questo Hackathon!");
        }

        // 5. Salvo il voto
        Valutazione v = new Valutazione(dto.getPunteggio(), dto.getGiudizio(), sottomissione, utente);
        return valutazioneRepo.save(v);
    }
}