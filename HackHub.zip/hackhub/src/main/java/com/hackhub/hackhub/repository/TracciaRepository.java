package com.hackhub.hackhub.repository;

import com.hackhub.hackhub.model.Traccia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TracciaRepository extends JpaRepository<Traccia, Long> {
}