package com.hackhub.hackhub.controller;


import com.hackhub.hackhub.dto.RegistrazioneDTO;
import com.hackhub.hackhub.model.Utente;
import com.hackhub.hackhub.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController // Dice a Spring che questo risponde alle chiamate web
@RequestMapping("/api/auth") // L'URL base per questo controller
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/registrazione") // Risponde a richieste POST
    public ResponseEntity<?> registra(@RequestBody RegistrazioneDTO dto) {
        try {
            Utente utenteCreato = authService.registraUtente(dto);
            return ResponseEntity.ok("Utente registrato con successo! ID: " + utenteCreato.getId());
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}