package com.hackhub.hackhub.dto;
public class GestioneCallDTO {
    private Long richiestaId;
    private Long mentoreId;

    public Long getRichiestaId() { return richiestaId; }
    public void setRichiestaId(Long rId) { this.richiestaId = rId; }
    public Long getMentoreId() { return mentoreId; }
    public void setMentoreId(Long mId) { this.mentoreId = mId; }
}
