package com.hackhub.hackhub.state;

public enum TipoStato {
    CREAZIONE, IN_ISCRIZIONE, IN_CORSO, IN_VALUTAZIONE, CONCLUSO
}