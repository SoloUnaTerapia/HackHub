package com.hackhub.hackhub.dto;

public class CreaValutazioneDTO {
    private Long sottomissioneId;
    private Long giudiceId;
    private int punteggio; // Da 0 a 10
    private String giudizio;

    public Long getSottomissioneId() { return sottomissioneId; }
    public void setSottomissioneId(Long sottomissioneId) { this.sottomissioneId = sottomissioneId; }
    public Long getGiudiceId() { return giudiceId; }
    public void setGiudiceId(Long giudiceId) { this.giudiceId = giudiceId; }
    public int getPunteggio() { return punteggio; }
    public void setPunteggio(int punteggio) { this.punteggio = punteggio; }
    public String getGiudizio() { return giudizio; }
    public void setGiudizio(String giudizio) { this.giudizio = giudizio; }
}