package com.hackhub.hackhub.dto;


public class CreaTeamDTO {
    private String nomeTeam;
    private Long leaderId; // Simula l'utente correntemente loggato

    // Getter e Setter
    public String getNomeTeam() { return nomeTeam; }
    public void setNomeTeam(String nomeTeam) { this.nomeTeam = nomeTeam; }
    public Long getLeaderId() { return leaderId; }
    public void setLeaderId(Long leaderId) { this.leaderId = leaderId; }
}