package com.hackhub.hackhub.service;

import com.hackhub.hackhub.dto.UtenteInfoDTO;
import com.hackhub.hackhub.repository.UtenteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UtenteService {

    @Autowired // Spring inietta automaticamente il Database qui!
    private UtenteRepository utenteRepository;

    public List<UtenteInfoDTO> getUtenti() {
        // Recupero tutti gli utenti dal DB
        return utenteRepository.findAll().stream().map(utente -> {

            // Controllo se l'utente ha un team
            String teamName = (utente.getTeam() != null) ? utente.getTeam().getNome() : "Nessun Team";

            // Creo il DTO sicuro (SENZA PASSWORD!)
            return new UtenteInfoDTO(
                    utente.getId(),
                    utente.getNome(),
                    utente.getEmail(),
                    teamName
            );
        }).collect(java.util.stream.Collectors.toList()); // Trasformo lo stream in Lista
    }
}
