package com.hackhub.hackhub.service;

import com.hackhub.hackhub.adapter.CalendarService;
import com.hackhub.hackhub.dto.GestioneCallDTO;
import com.hackhub.hackhub.model.*;
import com.hackhub.hackhub.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class SupportoService {

    @Autowired private RichiestaSupportoRepository supportoRepo;
    @Autowired private UtenteRepository utenteRepo;
    @Autowired private TeamRepository teamRepo;
    @Autowired private HackathonRepository hackRepo;
    @Autowired private CalendarService calendarService; // INIEZIONE DELL'ADAPTER!

    // 1. Il Team chiede aiuto
    public RichiestaSupporto chiediAiuto(Long teamId, Long mentoreId, Long hackId, String messaggio) {
        Team t = teamRepo.findById(teamId).orElseThrow();
        Utente m = utenteRepo.findById(mentoreId).orElseThrow();
        Hackathon h = hackRepo.findById(hackId).orElseThrow();

        // Controllo di business: il mentore scelto è davvero un mentore di questo hackathon?
        if (!h.getMentori().contains(m)) {
            throw new RuntimeException("L'utente selezionato non è un mentore di questo evento!");
        }

        RichiestaSupporto r = new RichiestaSupporto(messaggio, t, m, h);
        return supportoRepo.save(r);
    }

    // 2. Il Mentore fissa la Call
    public String programmaCall(GestioneCallDTO dto) {
        RichiestaSupporto r = supportoRepo.findById(dto.getRichiestaId()).orElseThrow();

        // Controllo sicurezza: sono io il mentore a cui l'hanno chiesta?
        if (!r.getMentore().getId().equals(dto.getMentoreId())) {
            throw new RuntimeException("Sicurezza: Non sei autorizzato a gestire questa richiesta!");
        }

        // Fissiamo per domani a quest'ora
        LocalDateTime orario = LocalDateTime.now().plusDays(1);

        // CHIAMO IL SISTEMA ESTERNO (Adapter)
        String link = calendarService.prenotaSlot(r.getMentore().getEmail(), r.getTeam().getLeader().getEmail(), orario);

        // Aggiorno il Database
        r.impostaCall(orario, link);
        supportoRepo.save(r);

        return link;
    }
}
