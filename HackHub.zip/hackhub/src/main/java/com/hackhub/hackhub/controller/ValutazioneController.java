package com.hackhub.hackhub.controller;

import com.hackhub.hackhub.dto.CreaValutazioneDTO;
import com.hackhub.hackhub.model.Valutazione;
import com.hackhub.hackhub.service.ValutazioneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/valutazioni")
public class ValutazioneController {

    @Autowired
    private ValutazioneService valutazioneService;

    @PostMapping("/vota")
    public ResponseEntity<?> vota(@RequestBody CreaValutazioneDTO dto) {
        try {
            Valutazione v = valutazioneService.aggiungiValutazione(dto);
            return ResponseEntity.ok("Valutazione salvata! ID: " + v.getId() + " - Voto: " + v.getPunteggio());
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}