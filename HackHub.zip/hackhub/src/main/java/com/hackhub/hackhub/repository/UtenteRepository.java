package com.hackhub.hackhub.repository;


import com.hackhub.hackhub.model.Utente;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

// JpaRepository ha già dentro save(), findById(), findAll(), delete()
public interface UtenteRepository extends JpaRepository<Utente, Long> {

    // Metodo magico: Spring traduce questo nome in "SELECT * FROM utente WHERE email = ?"
    Optional<Utente> findByEmail(String email);
}