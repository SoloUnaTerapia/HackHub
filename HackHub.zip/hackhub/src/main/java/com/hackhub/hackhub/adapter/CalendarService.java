package com.hackhub.hackhub.adapter;
import java.time.LocalDateTime;

public interface CalendarService {
    String prenotaSlot(String emailMentore, String emailTeam, LocalDateTime orario);
}