package com.hackhub.hackhub.adapter;
import org.springframework.stereotype.Component;

// Questa classe simula la libreria esterna (Adaptee). Ha metodi "strani".
@Component
public class PayPalExternalApi {

    // Metodo con firma diversa da quella che vorremmo noi
    public boolean sendMoneyTransaction(String accountEmail, String currency, double amount) {
        System.out.println("💳 [PAYPAL API] Connessione al server di PayPal...");
        System.out.println("💳 [PAYPAL API] Trasferimento di " + amount + " " + currency + " verso l'account: " + accountEmail);
        System.out.println("💳 [PAYPAL API] Esito: SUCCESS (HTTP 200)");
        return true;
    }
}
