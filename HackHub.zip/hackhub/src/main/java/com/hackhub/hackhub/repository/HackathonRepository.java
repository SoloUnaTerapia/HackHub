package com.hackhub.hackhub.repository;
import com.hackhub.hackhub.model.Hackathon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HackathonRepository extends JpaRepository<Hackathon, Long> {
}