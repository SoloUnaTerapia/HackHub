package com.hackhub.hackhub.adapter;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class GoogleCalendarAdapter implements CalendarService {
    @Override
    public String prenotaSlot(String emailMentore, String emailTeam, LocalDateTime orario) {
        System.out.println("📅[GOOGLE CALENDAR API] 📅");
        System.out.println("Creazione evento per il: " + orario);
        System.out.println("Partecipanti: " + emailMentore + " e " + emailTeam);
        // Simuliamo che Google ci restituisca il link della videochiamata
        return "https://meet.google.com/hack-" + System.nanoTime();
    }
}