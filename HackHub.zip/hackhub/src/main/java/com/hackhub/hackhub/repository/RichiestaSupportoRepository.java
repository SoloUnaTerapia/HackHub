package com.hackhub.hackhub.repository;
import com.hackhub.hackhub.model.RichiestaSupporto;
import org.springframework.data.jpa.repository.JpaRepository;
public interface RichiestaSupportoRepository extends JpaRepository<RichiestaSupporto, Long> {}
