package com.hackhub.hackhub.state;
import com.hackhub.hackhub.model.Hackathon;
import com.hackhub.hackhub.model.Team;
import com.hackhub.hackhub.model.Utente;

public class StatoInValutazione implements HackathonState {

    @Override
    public void iscriviTeam(Hackathon h, Team t) {
        throw new RuntimeException("Iscrizioni chiuse. Evento in fase di valutazione.");
    }

    @Override
    public void uploadSottomissione(Hackathon h) {
        throw new RuntimeException("Tempo scaduto! I team non possono più modificare i lavori.");
    }

    @Override
    public void valutaSottomissione(Hackathon h) {
        // LUCE VERDE! Qui il giudice può lavorare. Non lancia eccezioni.
    }

    @Override
    public void avanzaStato(Hackathon h) {
        h.setTipoStato(TipoStato.CONCLUSO);
        // h.setStatoComportamento(new StatoConcluso()); // Lo faremo alla fine
    }

    @Override
    public void proclamaVincitore(Hackathon h) {
        h.setTipoStato(TipoStato.CONCLUSO);
        h.setStatoComportamento(new StatoConcluso());
        System.out.println("STATO: L'Hackathon è ora CONCLUSO definitavamente.");
    }

    @Override
    public void assegnaGiudice(Hackathon h, Utente u) {
        throw new RuntimeException("ERRORE: Il Giudice può essere assegnato solo nella fase iniziale di Creazione!");
    }
}
