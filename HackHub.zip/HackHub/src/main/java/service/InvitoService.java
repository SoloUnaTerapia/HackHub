package service;
import model.*;
import repository.InvitoRepository;
import repository.UtenteRepository;

import java.util.List;

public class InvitoService {
    private InvitoRepository invitoRepo;
    private UtenteRepository utenteRepo; // Per salvare l'aggiornamento team

    public InvitoService(InvitoRepository iRepo, UtenteRepository uRepo) {
        this.invitoRepo = iRepo;
        this.utenteRepo = uRepo;
    }

    public void inviaInvito(Utente mittente, String emailRicevente, Team team) {

        Utente ricevente = utenteRepo.findByEmail(emailRicevente)
                .orElseThrow(() -> new RuntimeException("Utente non trovato"));

        Invito invito = new Invito(System.nanoTime(), mittente, ricevente, team);
        invitoRepo.save(invito);
        System.out.println("MAIL: Invito inviato a " + emailRicevente);
    }

    public void accettaInvito(Long idInvito) {
        Invito inv = invitoRepo.findById(idInvito).orElseThrow();


        Team t = inv.getTeam();
        Utente u = inv.getRicevente();
        t.getMembri().add(u);
        u.setTeam(t); // Aggiorna utente

        inv.setStato(Invito.StatoInvito.ACCEPTED);

        invitoRepo.save(inv);
        utenteRepo.save(u);
        System.out.println("INVITO: " + u.getNome() + " ora fa parte di " + t.getNome());
    }

    public List<Invito> getInvitiPendenti(Long idUtente) {

        Utente ricevente = utenteRepo.findById(idUtente)
                .orElseThrow(() -> new RuntimeException("Utente non trovato"));


        return invitoRepo.findByRiceventeAndStato(ricevente, Invito.StatoInvito.PENDING);
    }
}