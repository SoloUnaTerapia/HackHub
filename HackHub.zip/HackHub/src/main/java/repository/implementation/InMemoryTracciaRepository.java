package repository.implementation;
import model.Traccia;
import repository.TracciaRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InMemoryTracciaRepository implements TracciaRepository {


    private List<Traccia> db = new ArrayList<>();

    @Override
    public void save(Traccia t) {
        db.removeIf(old -> old.getId().equals(t.getId()));
        db.add(t);
    }

    @Override
    public Optional<Traccia> findById(Long id) {
        return db.stream().filter(t -> t.getId().equals(id)).findFirst();
    }


    @Override
    public List<Traccia> findAll() {

        return new ArrayList<>(db);
    }
}
