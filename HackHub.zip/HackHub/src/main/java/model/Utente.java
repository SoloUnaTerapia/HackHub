package model;

public class Utente {
    private Long id;
    private String nome;
    private String email;
    private String password;
    private Team team;

    public Utente(Long id, String nome,  String email, String password) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.password = password;
    }


    public Long getId() { return id; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getNome() {return nome;}
    public Team getTeam() { return team; }
    public void setTeam(Team team) { this.team = team; }

    @Override
    public String toString() { return nome + " " + email; }
}
